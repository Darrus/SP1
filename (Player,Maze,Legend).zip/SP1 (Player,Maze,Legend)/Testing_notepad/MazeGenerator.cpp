#include <iostream>
#include <fstream>
#include <string>
#include <Windows.h>
#include <conio.h>

using std::cout;
using std::cin;
using std::endl;
using std::ofstream;
using std::ifstream;
using std::ios;
using std::string;

bool quit = false;
void maze();
void mazearray();
char test[25][60];
char wall = 219;
char door = 254;
int play = 0;
COORD cursor;
int counter = 0;

string m1 = "m1OriginalCreation.txt";
string m2 = "m2ModifiedWintermaulMaze.txt";

void gotoXY(COORD c)
{
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),c);

}
void gotoXY(int x, int y) {
	COORD c = {x,y};
	gotoXY(c);
}
void setcolor(unsigned short color)
{
	HANDLE hcon = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hcon,color);
}

void player()
{
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),cursor);
	cout << (char)1;
	gotoXY(cursor.X,cursor.Y);
}
void movement()
{
	int ch = _getch();
	switch(ch)
	{
	case 'w':
	case 'W':
	case 72:
		if(cursor.Y > 0 && test[cursor.Y-1][cursor.X] == '0')
		{
			cursor.Y--;
		}
		break;
	case 's':
	case 'S':
	case 80:
		if(cursor.Y < 24 && test[cursor.Y+1][cursor.X] == '0')
		{
			cursor.Y++;
		}
		break;
	case 'd':
	case 'D':
	case 77:
		if(cursor.X < 79 && test[cursor.Y][cursor.X+1] == '0')
		{
			cursor.X++;
		}
		break;
	case 'a':
	case 'A':
	case 75:
		if(cursor.X > 0 && test[cursor.Y][cursor.X-1] == '0')
		{
			cursor.X--;
		}
		break;
	case 27:
		quit = true;
		break;
	}
}

void legend()
{
	gotoXY(54, 5);
	setcolor(0x02);
	cout << "Player = Green " << (char)1  << endl;
	gotoXY(54, 6);
	setcolor(0x0C);
	cout << "FOE = Red ^v<>" << endl;
	gotoXY(54, 7);
	setcolor(0x0C);
	cout << "Unstable Floors = Red 0" << endl;
	gotoXY(54, 8);
	setcolor(0x0C);
	cout << "Broken Floors = Red O" << endl;
	gotoXY(54, 9);
	setcolor(0x0E);
	cout << "Keys = Yellow *" << endl;
	gotoXY(54, 10);
	setcolor(0x0f);
	cout << "Walls = White " << wall << endl;
	gotoXY(54, 11);
	cout << "Door = White " << door << endl;
	setcolor(7);
}

void main()
{
	while(!quit)
	{
		maze();
		legend();
		player();
		movement();
	}
}

//maze function
void mazemapping(int Height,int Length)
{
	int h = Height;
	int a = Length;
	switch(test[h][a])
	{
		case '0':cout << " "; 
			break;
		case '1':setcolor(0x0f);cout << wall;setcolor(7);
			break;
		case '2':setcolor(0x0f);cout << door;setcolor(7);
			break;
		case 'x': cout << "O";test[h][a] = '0';
			break;
		case '!':setcolor(14);cout << "*";setcolor(7);
			break;
		case 'H':setcolor(12);cout << "H";setcolor(7); 
			break;
		case 'V':setcolor(12);cout << "V";setcolor(7);
			break;
		case 'O':setcolor(12);cout << "O";setcolor(7);
			break;
		case 'S':
			{
			cout << ' ';
			test[h][a] = '0';
			if(play == 0)
			{
				cursor.X = a;
				cursor.Y = h;
				play++;
			}
			}
			break;
		case '?':cout << "?";
			break;
		case '\n':cout << endl;
			break;
		}	
}
//void mazearray()
//{
//	gotoXY(0,0);
//	ifstream fin;
//	fin.open(m2, ios::in);
//	while(!fin.eof() )
//	{	
//		fin.getline(test[h],50);
//		for(int a = 0;test[h][a] != '\0'; ++a)
//		{
//			mazemapping(h,a);
//		}
//		cout << endl;
//		++h;
//	}
//	
//	cout << endl;
//}
void maze()
{
	int a = 0;
	int h = 0;
	gotoXY(0,0);
	ifstream fin;
	fin.open(m2,ios::in);
	while(!fin.eof())
	{	
		fin.getline(test[h],60);
		for(a = 0;test[h][a] != '\0'; ++a)
		{
			mazemapping(h,a);
		}
		cout << endl;
		++h;
	}
	cout << endl;
}